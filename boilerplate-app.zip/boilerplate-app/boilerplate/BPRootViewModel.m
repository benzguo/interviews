#import "BPRootViewModel.h"

@implementation BPRootViewModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _title = @"Root";
    }
    return self;
}

@end
