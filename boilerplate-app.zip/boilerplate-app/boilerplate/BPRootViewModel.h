#import <Foundation/Foundation.h>

@interface BPRootViewModel : NSObject

@property (nonatomic, readonly) NSString *title;

@end
