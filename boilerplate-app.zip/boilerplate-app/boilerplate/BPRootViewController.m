#import "BPRootViewController.h"
#import "BPRootViewModel.h"
#import "BPLogger.h"

NSString *const BPLoggerClientId = @"foo";

@interface BPRootViewController ()

@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) BPLogger *logger;

@end

@implementation BPRootViewController

- (instancetype)initWithViewModel:(BPRootViewModel *)viewModel
{
    self = [super init];
    if (self) {
        self.title = viewModel.title;
        self.logger = [[BPLogger alloc] initWithClientId:BPLoggerClientId];
    }
    return self;
}

- (void)loadView
{
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor whiteColor];

    self.button = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.button setTitle:@"GO" forState:UIControlStateNormal];
    [self.button sizeToFit];
    @weakify(self)
    self.button.rac_command = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
        @strongify(self)
        BPLoggerEvent *event = [[BPLoggerEvent alloc] initWithDate:[NSDate date] data:@{@"foo": @"bar"}];
        [self.logger logEvent:event];
        return [RACSignal empty];
    }];
    [view addSubview:self.button];

    self.view = view;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    self.button.center = self.view.center;
}

@end
