@import UIKit;

@class BPRootViewModel;
@interface BPRootViewController : UIViewController

- (instancetype)initWithViewModel:(BPRootViewModel *)viewModel;

@end

